﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Почта
{
    internal class Pochta
    {

        public string Street { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }

        public void ChangeSt(string newstreet)
        {
            this.Street = newstreet;
        }
        public void ChangeCit(string newcity)
        {
            this.City = newcity;
        }
        public void ChangePos(string pos)
        {
            this.PostalCode = pos;
        }
    }
}
