﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var4
{
    internal class Array
    {
        private int[] array;
        Random rnd = new Random();
        public int[] Size(int size)
        {
            array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = rnd.Next(-100, 100);
            }
            return array;
        }

        public int Ind(int[] mas, int index)
        {
            return mas[index];
        }
        public int[] Out(int[] m, int index)
        {
            int k = 0;
            for (int i = index; i < m.Count(); i++)
            {
                k++;
            }
            int[] m2 = new int[k];
            int j = 0;
            for (int i = index; i < m.Count(); i++)
            {
                m2[j] = m[i];
                j++;
            }
            return m2;
        }
        public int[] Umn(int[] m, int m2)
        {
            for (int i = 0; i < m.Length; i++)
            {
                m[i] *= m2;
            }
            return m;
        }
        public ArrayList Action(int[] m1, int[] m2, string answer)
        {
            ArrayList l = new ArrayList();
            if (answer == "+")
                for (int i = 0; i < m1.Count(); i++)
                {
                    l.Add(m1[i] + m2[i]);
                }
            else
                for (int i = 0; i < m1.Count(); i++)
                {
                    l.Add(m1[i] - m2[i]);
                }
            return l;
        }
    }
}
