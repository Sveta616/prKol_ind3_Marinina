﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("file1.txt"))
            {
                Array array = new Array();
                ArrayList l = new ArrayList();
                int s = 0,
                index = 0,
                num = 0,
                j = 0;
                bool a = false;
                string plmn = "", v = "";
                do
                {
                    do
                    {
                        Console.WriteLine("Введите размер массива: ");
                        try
                        {
                            s = int.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Введите корректно");
                        }

                    }
                    while (s <= 0 || s > 20);
                    int[] m = array.Size(s);
                    for (int i = 0; i < m.Length; i++)
                    {
                        Console.WriteLine($"{m[i]} ");
                    }
                    StreamWriter sr = File.CreateText("file1.txt");
                    for (int i = 0; i < m.Length; i++)
                        sr.WriteLine(m[i]);
                    sr.Close();
                    do
                    {
                        Console.WriteLine("Введите позицию элемента, который вы хотите увидеть(начинайте с 1): ");
                        try
                        {
                            index = int.Parse(Console.ReadLine()) - 1;
                            if (index > m.Length) Console.WriteLine("Вы вышли за границы массива");
                            if (index < 0) Console.WriteLine("Вы ввели число < 1");
                        }
                        catch { Console.WriteLine("Введите корректно"); }

                    }
                    while (index < 0 || index > m.Length);
                    Console.WriteLine($"{array.Ind(m, index)}");
                    do
                    {
                        Console.WriteLine("Введите позицию элемента, который вы хотите увидеть(начинайте с 1): ");
                        try
                        {
                            index = int.Parse(Console.ReadLine()) - 1;
                            if (index > m.Length) Console.WriteLine("Вы вышли за границы массива");
                            if (index < 0) Console.WriteLine("Вы ввели число <1");
                        }
                        catch { Console.WriteLine("Введите корректно"); }

                    }
                    while (index < 0 || index > m.Length);
                    int[] mass = array.Out(m, index);
                    for (int i = 0; i < mass.Count(); i++)
                    {
                        Console.WriteLine($"{mass[i]} ");
                    }
                    do
                    {
                        Console.WriteLine("Введите число, на которое будем умножать массив: ");
                        try
                        {
                            num = int.Parse(Console.ReadLine());
                            a = true;
                        }
                        catch
                        {
                            Console.WriteLine("Введите корректно");
                            a = false;
                        }

                    }
                    while (a == false);
                    int[] mas = array.Umn(m, num);
                    for (int i = 0; i < mas.Count(); i++)
                    {
                        Console.WriteLine($"{mas[i]} ");
                    }
                    do
                    {
                        do
                        {
                            Console.WriteLine("Выберите действие (+/-): ");
                            plmn = Convert.ToString(Console.ReadLine());
                        }
                        while (!(plmn == "+" || plmn == "-"));
                        int[] m2 = array.Size(m.Length);
                        int[] m3 = new int[m.Length];
                        StreamReader sw = File.OpenText("file1.txt");
                        while (!sw.EndOfStream)
                        {
                            m3[j] = Convert.ToInt32(sw.ReadLine());
                            j++;
                        }
                        sw.Close();
                        Console.WriteLine("Первый массив: ");
                        for (int i = 0; i < m3.Length; i++)
                        {
                            Console.WriteLine($"{m3[i]} ");
                        }
                        Console.WriteLine("Второй массив: ");
                        for (int i = 0; i < m2.Length; i++)
                        {
                            Console.WriteLine($"{m2[i]} ");
                        }
                        l = array.Action(m3, m2, plmn);
                        Console.WriteLine("Новый массив: ");
                        foreach (object action in l)
                        {
                            Console.WriteLine($"{action} ");
                        }
                        Console.WriteLine("Завершить операцию сложения/вычитания массивов? (да/нет): ");
                        v = Convert.ToString(Console.ReadLine());
                    }
                    while (!(v == "да" || v == "Да"));
                    Console.WriteLine("Завершить действия с одномерными массивами? (да / нет) : ");
                    v = Convert.ToString(Console.ReadLine());
                }
                while (!(v == "да" || v == "Да"));

            }
            else Console.WriteLine("Файла нет");

            Console.ReadKey();
        }
    }
}
